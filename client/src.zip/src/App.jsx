import { useEffect, useMemo, useState } from "react";
import { MapContainer, TileLayer, Circle, Tooltip } from "react-leaflet";
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip as RTooltip } from "recharts";
import "leaflet/dist/leaflet.css";
import {
  LayoutDashboard, CloudSun, Radar, Wind, CloudRain, Thermometer, Satellite, Leaf,
  Waves, Bell, BarChart3, FileText, Key, Settings, Search, Sparkles, Play, Pause,
  Send, Database, Globe, Network, ShieldCheck, Brain, MapPin, Droplets, Sun,
} from "lucide-react";

/* ================= CONFIG ================= */
// Relative path: Vite proxy (/api -> http://localhost:5000) use hoy, CORS/port problem hoy na
const CHAT_URL = "/api/chat";
const RURAL = [22.95, 88.2];

/* ================= STATIC ZONE DATA ================= */
const ZONES = [
  { name: "Howrah Industrial", pos: [22.589, 88.31], ndvi: 0.08, albedo: 0.1, hvi: 0.92 },
  { name: "Burrabazar Core", pos: [22.581, 88.355], ndvi: 0.05, albedo: 0.09, hvi: 0.97 },
  { name: "Salt Lake Sector V", pos: [22.573, 88.433], ndvi: 0.22, albedo: 0.16, hvi: 0.6 },
  { name: "Park Street", pos: [22.552, 88.352], ndvi: 0.18, albedo: 0.14, hvi: 0.68 },
  { name: "Maidan Green Belt", pos: [22.558, 88.343], ndvi: 0.66, albedo: 0.2, hvi: 0.18 },
  { name: "Dum Dum Airport", pos: [22.65, 88.447], ndvi: 0.12, albedo: 0.13, hvi: 0.74 },
  { name: "Tollygunge", pos: [22.498, 88.345], ndvi: 0.34, albedo: 0.17, hvi: 0.46 },
  { name: "New Town", pos: [22.58, 88.479], ndvi: 0.45, albedo: 0.19, hvi: 0.33 },
];

/* ================= HELPERS ================= */
// real surface temp (Open-Meteo soil_temperature_0cm) + estimated offset from HVI
const lst = (z, h) => (z.series ? z.series[h] : 35) + (z.hvi - 0.5) * 3;
const heatColor = (t) => `hsl(${Math.round(230 - 230 * Math.min(1, Math.max(0, t)))} 90% 55%)`;
const fmtH = (h) => `${String(h % 24).padStart(2, "0")}:00`;
const WMO = (c) =>
  c === 0 ? "Clear" : c <= 3 ? "Partly Cloudy" : c <= 48 ? "Fog/Haze" : c <= 67 ? "Rain" : c <= 82 ? "Showers" : "Thunderstorm";

const LAYERS = [
  { id: "lst", label: "Surface Temp", icon: Thermometer, color: "#ef4444", heat: (z, h) => (lst(z, h) - 28) / 22, show: (z, h) => `${lst(z, h).toFixed(1)} °C` },
  { id: "uhi", label: "UHI ΔT", icon: Sun, color: "#f97316", heat: (z, h) => (z.air[h] - z.rural) / 6, show: (z, h) => `${(z.air[h] - z.rural).toFixed(1)} °C` },
  { id: "ndvi", label: "Vegetation NDVI", icon: Leaf, color: "#22c55e", heat: (z) => 1 - z.ndvi / 0.7, show: (z) => z.ndvi.toFixed(2) },
  { id: "albedo", label: "Surface Albedo", icon: Satellite, color: "#a78bfa", heat: (z) => 1 - z.albedo / 0.22, show: (z) => z.albedo.toFixed(2) },
  { id: "hvi", label: "Heat Vulnerability", icon: Bell, color: "#ec4899", heat: (z) => z.hvi, show: (z) => z.hvi.toFixed(2) },
  { id: "hum", label: "Humidity", icon: Droplets, color: "#38bdf8", heat: (z) => 1 - z.hum / 85, show: (z) => `${z.hum}%` },
];

const NAV = [
  [LayoutDashboard, "Dashboard"], [CloudSun, "Live Weather"], [Radar, "Radar"], [Wind, "Wind"],
  [CloudRain, "Rainfall"], [Thermometer, "Temperature"], [Satellite, "Satellite"], [Leaf, "Vegetation"],
  [Waves, "Marine"], [Bell, "Alerts"], [BarChart3, "Climate Analytics"], [FileText, "Reports"],
  [Key, "API Access"], [Settings, "Settings"],
];

/* ================= LIVE DATA (Open-Meteo, no key) ================= */
async function loadLive() {
  const pts = [...ZONES.map((z) => z.pos), RURAL];
  const lat = pts.map((p) => p[0]).join(",");
  const lon = pts.map((p) => p[1]).join(",");
  const wUrl =
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&hourly=temperature_2m,soil_temperature_0cm,relative_humidity_2m,uv_index,visibility` +
    `&daily=temperature_2m_max,temperature_2m_min` +
    `&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,surface_pressure,weather_code,dew_point_2m` +
    `&timezone=Asia%2FKolkata&forecast_days=7`;
  const aUrl =
    `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=22.57&longitude=88.36` +
    `&current=us_aqi,pm2_5&timezone=Asia%2FKolkata`;

  const [w, aq] = await Promise.all([
    fetch(wUrl).then((r) => r.json()),
    fetch(aUrl).then((r) => r.json()),
  ]);
  const arr = Array.isArray(w) ? w : [w];
  const zones = ZONES.map((z, i) => ({
    ...z,
    air: arr[i].hourly.temperature_2m,
    series: arr[i].hourly.soil_temperature_0cm,
    humS: arr[i].hourly.relative_humidity_2m,
  }));
  const rural = arr[arr.length - 1];
  return {
    zones,
    ruralAir: rural.hourly.temperature_2m,
    cur: arr[1].current,
    daily: arr[1].daily,
    uv: arr[1].hourly.uv_index,
    vis: arr[1].hourly.visibility,
    aqi: aq.current,
    at: new Date(),
  };
}

/* ================= SMALL COMPONENTS ================= */
function Gauge({ value, max, unit, label, color, sub }) {
  const r = 26, c = 2 * Math.PI * r, p = Math.min(1, Math.max(0, value / max));
  return (
    <div className="mi-gauge">
      <div className="mi-gauge-t">{label}</div>
      <svg width="72" height="72" viewBox="0 0 72 72">
        <circle cx="36" cy="36" r={r} fill="none" stroke="rgba(120,150,220,.15)" strokeWidth="5" />
        <circle cx="36" cy="36" r={r} fill="none" stroke={color} strokeWidth="5" strokeLinecap="round"
          strokeDasharray={`${c * p * 0.75} ${c}`} transform="rotate(135 36 36)"
          style={{ filter: `drop-shadow(0 0 5px ${color})`, transition: "all .6s" }} />
        <text x="36" y="38" textAnchor="middle" fill="#fff" fontSize="16" fontWeight="700">{value}</text>
        <text x="36" y="50" textAnchor="middle" fill="#8ea2c8" fontSize="8">{unit}</text>
      </svg>
      <div className="mi-gauge-s">{sub}</div>
    </div>
  );
}

function Panel({ title, icon: Icon, children, className = "" }) {
  return (
    <div className={`mi-panel ${className}`}>
      {title && (
        <div className="mi-panel-h">
          {Icon && <Icon size={13} />} {title}
        </div>
      )}
      {children}
    </div>
  );
}

/* ================= MAIN APP ================= */
export default function App() {
  const [live, setLive] = useState(null);
  const [err, setErr] = useState("");
  const [layer, setLayer] = useState("lst");
  const [on, setOn] = useState({ lst: true, uhi: true, ndvi: true, albedo: true, hvi: true, hum: true });
  const [hour, setHour] = useState(new Date().getHours());
  const [playing, setPlaying] = useState(false);
  const [mode, setMode] = useState("Now");
  const [msg, setMsg] = useState("");
  const [chat, setChat] = useState([]);
  const [busy, setBusy] = useState(false);
  const [selName, setSelName] = useState("Burrabazar Core");

  // fetch live data now + every 10 min
  useEffect(() => {
    const go = () =>
      loadLive()
        .then((d) => { setLive(d); setErr(""); })
        .catch((e) => setErr(String(e)));
    go();
    const t = setInterval(go, 10 * 60 * 1000);
    return () => clearInterval(t);
  }, []);

  // timeline playback
  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setHour((h) => (h + 1) % 24), 900);
    return () => clearInterval(t);
  }, [playing]);

  const zones = useMemo(
    () => (live ? live.zones.map((z) => ({ ...z, hum: Math.round(z.humS[hour]), rural: live.ruralAir[hour] })) : []),
    [live, hour]
  );

  if (!live)
    return (
      <div className="mi-root" style={{ display: "grid", placeItems: "center" }}>
        <style>{CSS}</style>
        {err ? `Data load hoyni: ${err}` : "Loading live microclimate data..."}
      </div>
    );

  const L = LAYERS.find((l) => l.id === layer);
  const sel = zones.find((z) => z.name === selName) || zones[0];
  const urbanAir = (h) => live.zones.reduce((a, z) => a + z.air[h], 0) / live.zones.length;
  const diurnal = Array.from({ length: 24 }, (_, h) => ({
    h: fmtH(h),
    urban: +urbanAir(h).toFixed(1),
    rural: +live.ruralAir[h].toFixed(1),
  }));
  const peak = zones.reduce((a, z) => (lst(z, hour) > lst(a, hour) ? z : a));
  const dT = Math.max(0, urbanAir(hour) - live.ruralAir[hour]).toFixed(1);
  const cur = live.cur;
  const visKm = Math.round((live.vis[hour] ?? 10000) / 1000);
  const aqiV = live.aqi?.us_aqi ?? 0;
  const aqiTxt = aqiV <= 50 ? "Good" : aqiV <= 100 ? "Moderate" : aqiV <= 150 ? "Unhealthy (Sens.)" : "Unhealthy";
  const aqiCol = aqiV <= 50 ? "#4ade80" : aqiV <= 100 ? "#facc15" : "#ef4444";
  const days = live.daily.time.map((d) => new Date(d).toLocaleDateString("en", { weekday: "short" }));

  const send = async () => {
    if (!msg.trim() || busy) return;
    const q = msg;
    setMsg("");
    setBusy(true);
    setChat((c) => [...c, { u: q }]);
    try {
      const r = await fetch(CHAT_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: q,
          context: {
            hour: fmtH(hour),
            cityAirTemp: +urbanAir(hour).toFixed(1),
            ruralAirTemp: +live.ruralAir[hour].toFixed(1),
            uhiDeltaT: +dT,
            usAqi: aqiV,
            zones: zones.map((z) => ({
              name: z.name, surfaceTemp: +lst(z, hour).toFixed(1), ndvi: z.ndvi, albedo: z.albedo, hvi: z.hvi,
            })),
          },
        }),
      });
      const d = await r.json();
      setChat((c) => [...c, { a: d.reply || d.error || "Kono reply ashe ni" }]);
    } catch {
      setChat((c) => [...c, { a: "Backend-e connect hocche na (port 5000 cholche to?)" }]);
    }
    setBusy(false);
  };

  return (
    <div className="mi-root">
      <style>{CSS}</style>

      {/* TOP BAR */}
      <header className="mi-top">
        <div className="mi-logo">
          <div className="mi-logo-i"><Leaf size={18} /></div>
          <div><b>AURA</b><span>INTELLIGENCE</span></div>
        </div>
        <div className="mi-search"><Search size={13} /> Global Search... <kbd>⌘K</kbd></div>
        <div className="mi-loc"><MapPin size={13} /> Kolkata, India <small>22.57°N, 88.36°E</small></div>
        <div className="mi-chip"><Sparkles size={13} /> AI Assistant</div>
        <div className="mi-live"><i /> LIVE <small>updated {live.at.toLocaleTimeString()}</small></div>
        <div className="mi-bell"><Bell size={15} /><em>3</em></div>
      </header>

      <div className="mi-body">
        {/* SIDEBAR */}
        <aside className="mi-side">
          {NAV.map(([I, n], i) => (
            <div key={n} className={`mi-nav ${i === 0 ? "act" : ""}`}><I size={14} /> {n}</div>
          ))}
        </aside>

        {/* CENTER */}
        <main className="mi-center">
          <div className="mi-hero">
            <div>
              <div className="mi-case">CASE STUDY</div>
              <h1>Built for Predictability.<br /><span>Designed for Operations.</span></h1>
            </div>
            <div className="mi-feats">
              {[[Network, "Real-Time Data", "Open-Meteo live"], [Brain, "AI Intelligence", "Gemini powered"],
                [Globe, "Urban Coverage", "8 zones"], [ShieldCheck, "Enterprise Grade", "Secure & reliable"]]
                .map(([I, a, b]) => (
                  <div key={a} className="mi-feat"><I size={18} /><div><b>{a}</b><small>{b}</small></div></div>
                ))}
            </div>
          </div>

          <div className="mi-mapwrap">
            <MapContainer center={[22.57, 88.38]} zoom={11} zoomControl={false}
              style={{ height: "100%", width: "100%", background: "#030814" }}>
              <TileLayer url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png" attribution="&copy; CARTO" />
              {on[layer] && zones.map((z) => {
                const t = L.heat(z, hour);
                return (
                  <Circle key={z.name} center={z.pos} radius={2600 + Math.max(0, t) * 1800}
                    pathOptions={{ color: heatColor(t), fillColor: heatColor(t), fillOpacity: 0.38, weight: 1.5 }}
                    eventHandlers={{ click: () => setSelName(z.name) }}>
                    <Tooltip>{z.name}: {L.show(z, hour)}</Tooltip>
                  </Circle>
                );
              })}
            </MapContainer>

            {/* layers overlay */}
            <div className="mi-layers">
              <div className="mi-lh">LAYERS</div>
              {LAYERS.map((l) => (
                <div key={l.id} className={`mi-lrow ${layer === l.id ? "act" : ""}`} onClick={() => setLayer(l.id)}>
                  <l.icon size={12} color={l.color} /> <span>{l.label}</span>
                  <input type="checkbox" checked={on[l.id]} onClick={(e) => e.stopPropagation()}
                    onChange={() => setOn({ ...on, [l.id]: !on[l.id] })} />
                </div>
              ))}
            </div>

            {/* selected zone card */}
            <div className="mi-storm">
              <div className="mi-sh"><Sparkles size={14} color="#a855f7" /> <b>{sel.name}</b>
                <em>HVI {sel.hvi.toFixed(2)}</em></div>
              {[["LST", `${lst(sel, hour).toFixed(1)} °C`], ["Air", `${sel.air[hour].toFixed(1)} °C`],
                ["NDVI", sel.ndvi.toFixed(2)], ["Albedo", sel.albedo.toFixed(2)], ["Humidity", `${sel.hum}%`]]
                .map(([a, b]) => (
                  <div key={a} className="mi-kv"><span>{a}</span><b>{b}</b></div>
                ))}
              <div className="mi-btns"><button>View Track</button><button>Details</button></div>
            </div>

            <div className="mi-legend"><span>Cool</span><i /><span>Extreme Heat</span></div>
          </div>

          {/* gauges */}
          <div className="mi-gauges">
            <Gauge label="TEMP" value={Math.round(cur.temperature_2m)} max={50} unit="°C" color="#f97316" sub="Right now" />
            <Gauge label="UHI ΔT" value={+dT} max={10} unit="°C" color="#ef4444" sub="vs rural" />
            <Gauge label="HUMIDITY" value={Math.round(cur.relative_humidity_2m)} max={100} unit="%" color="#22d3ee" sub={`Dew pt ${Math.round(cur.dew_point_2m)}°`} />
            <Gauge label="WIND" value={Math.round(cur.wind_speed_10m)} max={60} unit="km/h" color="#22c55e" sub="10 m" />
            <Gauge label="UV INDEX" value={Math.round(live.uv[hour])} max={12} unit="UV" color="#a855f7" sub={live.uv[hour] > 7 ? "Very High" : "Moderate"} />
            <Gauge label="VISIBILITY" value={visKm} max={24} unit="km" color="#3b82f6" sub="Horizontal" />
          </div>

          {/* bottom row */}
          <div className="mi-row3">
            <Panel title="AI Climate Intelligence" icon={Sparkles}>
              <div className="mi-chat">
                <p className="mi-hi">Live heat summary<br /><small>Real data diye Gemini analyse korbe.</small></p>
                <ul>
                  <li>Hottest zone: <b>{peak.name}</b> ({lst(peak, hour).toFixed(1)}°C)</li>
                  <li>City vs rural: <b>+{dT}°C</b></li>
                </ul>
                {chat.map((m, i) => <div key={i} className={m.u ? "u" : "a"}>{m.u || m.a}</div>)}
                {busy && <div className="a">Thinking...</div>}
                <div className="mi-in">
                  <input value={msg} onChange={(e) => setMsg(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && send()} placeholder="Ask anything about heat..." />
                  <button onClick={send}><Send size={12} /></button>
                </div>
              </div>
            </Panel>

            <Panel title="Timeline Playback Controls">
              <div className="mi-time">
                <div className="mi-tc">
                  <button className="mi-play" onClick={() => setPlaying(!playing)}>
                    {playing ? <Pause size={14} /> : <Play size={14} />}
                  </button>
                  <input type="range" min="0" max="23" value={hour} onChange={(e) => setHour(+e.target.value)} />
                  <span className="mi-badge">{fmtH(hour)}</span>
                </div>
                <div className="mi-tabs">
                  {["Now", "Forecast", "History"].map((m) => (
                    <button key={m} className={mode === m ? "act" : ""} onClick={() => setMode(m)}>{m}</button>
                  ))}
                </div>
                <div className="mi-lg">Surface Temperature (°C)</div>
                <div className="mi-bar" />
                <div className="mi-ticks"><span>28</span><span>32</span><span>36</span><span>40</span><span>44</span><span>48</span><span>50</span></div>
              </div>
            </Panel>

            <Panel title="Operational Analytics" icon={BarChart3}>
              <div style={{ height: 150 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={diurnal} margin={{ top: 8, right: 6, left: -22, bottom: 0 }}>
                    <defs>
                      <linearGradient id="gu" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#3b82f6" stopOpacity=".5" />
                        <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="h" tick={{ fill: "#6f84ad", fontSize: 9 }} interval={5} axisLine={false} tickLine={false} />
                    <YAxis tick={{ fill: "#6f84ad", fontSize: 9 }} axisLine={false} tickLine={false} domain={["dataMin - 1", "dataMax + 1"]} />
                    <RTooltip contentStyle={{ background: "#0a1428", border: "1px solid #25407a", fontSize: 11 }} />
                    <Area type="monotone" dataKey="urban" stroke="#60a5fa" strokeWidth={2} fill="url(#gu)" />
                    <Area type="monotone" dataKey="rural" stroke="#22c55e" strokeWidth={1.5} fill="none" strokeDasharray="4 3" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="mi-cap">Real air temp today: urban (blue) vs rural (green dashed)</div>
            </Panel>
          </div>

          {/* stats strip */}
          <div className="mi-stats">
            {[[Database, "2", "Live APIs"], [Globe, "8", "Urban Zones"], [Network, "168", "Forecast Hours"],
              [ShieldCheck, "10 min", "Auto Refresh"], [Brain, "Gemini", "AI Model"]].map(([I, a, b]) => (
              <div key={b}><I size={22} /><div><b>{a}</b><small>{b}</small></div></div>
            ))}
          </div>
        </main>

        {/* RIGHT PANEL */}
        <aside className="mi-right">
          <Panel title="Forecast Analytics" icon={BarChart3} className="mi-fa">
            <div className="mi-cur-h">CURRENT CONDITIONS</div>
            <div className="mi-cur">
              <CloudSun size={40} color="#93c5fd" />
              <div className="mi-big">{Math.round(cur.temperature_2m)}<sup>°C</sup>
                <small>{WMO(cur.weather_code)}</small>
                <small>Feels like {Math.round(cur.apparent_temperature)}°</small>
              </div>
              <div className="mi-mini">
                <span>Humidity <b>{Math.round(cur.relative_humidity_2m)}%</b></span>
                <span>Wind <b>{Math.round(cur.wind_speed_10m)} km/h</b></span>
                <span>Pressure <b>{Math.round(cur.surface_pressure)} hPa</b></span>
                <span>Visibility <b>{visKm} km</b></span>
              </div>
            </div>

            <div className="mi-cur-h">HOURLY FORECAST</div>
            <div className="mi-hourly">
              {[0, 2, 4, 6, 8, 10].map((o, i) => {
                const idx = hour + o;
                return (
                  <div key={o}>
                    <small>{i === 0 ? "Now" : fmtH(idx)}</small>
                    <Sun size={15} color="#fbbf24" />
                    <b>{urbanAir(idx).toFixed(0)}°</b>
                  </div>
                );
              })}
            </div>

            <div className="mi-cur-h">7-DAY HEAT OUTLOOK</div>
            {days.map((d, i) => {
              const hi = live.daily.temperature_2m_max[i], lo = live.daily.temperature_2m_min[i];
              return (
                <div key={d + i} className="mi-day">
                  <span>{i === 0 ? "Today" : d}</span><small>{Math.round(lo)}°</small>
                  <div className="mi-rng"><i style={{ left: `${(lo - 10) * 3}%`, width: `${(hi - lo) * 3}%` }} /></div>
                  <small>{Math.round(hi)}°</small>
                </div>
              );
            })}

            <div className="mi-cur-h">AIR QUALITY INDEX (US)</div>
            <div className="mi-aqi">
              <b style={{ color: aqiCol }}>{aqiV}</b>
              <span style={{ color: aqiCol }}>{aqiTxt}</span>
              <small style={{ color: "#8ea2c8" }}>PM2.5 {live.aqi?.pm2_5} µg/m³</small>
            </div>

            <div className="mi-cur-h">HEAT ALERTS</div>
            {zones
              .map((z) => ({ z, t: lst(z, hour) }))
              .sort((a, b) => b.t - a.t)
              .slice(0, 3)
              .map(({ z, t }) => {
                const c = t > 43 ? "#ef4444" : t > 38 ? "#f59e0b" : "#22c55e";
                return (
                  <div key={z.name} className="mi-al" style={{ borderColor: c + "55" }}>
                    <i style={{ background: c }} />
                    <div>
                      <b>{t > 43 ? "Extreme Heat" : t > 38 ? "Heat Advisory" : "Normal"}</b>
                      <small>{z.name} · {t.toFixed(1)}°C</small>
                    </div>
                  </div>
                );
              })}
          </Panel>
        </aside>
      </div>
    </div>
  );
}

/* ================= STYLES ================= */
const CSS = `
*{box-sizing:border-box}
.mi-root{min-height:100vh;color:#e6eeff;font-family:Inter,system-ui,sans-serif;font-size:12px;
background:radial-gradient(1200px 600px at 20% -10%,#0b2a6b55,transparent),radial-gradient(900px 500px at 100% 100%,#0a5a4a44,transparent),#050a18;padding:14px}
.mi-top{display:flex;align-items:center;gap:10px;margin-bottom:12px}
.mi-logo{display:flex;align-items:center;gap:8px;margin-right:12px}
.mi-logo-i{width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,#22d3ee,#2563eb);box-shadow:0 0 18px #22d3ee66}
.mi-logo b{display:block;letter-spacing:.2em;font-size:15px}.mi-logo span{font-size:8px;letter-spacing:.3em;color:#8ea2c8}
.mi-search,.mi-loc,.mi-chip,.mi-live,.mi-bell{display:flex;align-items:center;gap:6px;padding:8px 12px;border-radius:10px;background:#0a1530cc;border:1px solid #1e3a7a66;color:#9fb2d8}
.mi-search{flex:1;max-width:260px}.mi-search kbd{margin-left:auto;font-size:9px;background:#13244a;padding:1px 5px;border-radius:4px}
.mi-loc small{color:#6f84ad}.mi-chip{color:#c4b5fd;border-color:#7c3aed66}
.mi-live{margin-left:auto;color:#4ade80;font-weight:700}.mi-live i{width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 8px #22c55e;animation:p 1.4s infinite}
.mi-live small{color:#8ea2c8;font-weight:400}.mi-bell{position:relative}.mi-bell em{position:absolute;top:-4px;right:-4px;background:#ef4444;color:#fff;border-radius:99px;font-size:9px;padding:0 5px;font-style:normal}
@keyframes p{50%{opacity:.3}}
.mi-body{display:grid;grid-template-columns:150px 1fr 290px;gap:12px}
.mi-side{background:#08122acc;border:1px solid #1e3a7a55;border-radius:14px;padding:8px;height:fit-content}
.mi-nav{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;color:#8ea2c8;cursor:pointer}
.mi-nav:hover{background:#12234a}.mi-nav.act{background:linear-gradient(90deg,#1d4ed855,transparent);color:#fff;box-shadow:inset 2px 0 #3b82f6}
.mi-center{min-width:0;display:flex;flex-direction:column;gap:12px}
.mi-hero{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}
.mi-case{color:#3b82f6;letter-spacing:.2em;font-size:10px;margin-bottom:4px}
.mi-hero h1{margin:0;font-size:26px;line-height:1.15}.mi-hero h1 span{background:linear-gradient(90deg,#60a5fa,#22d3ee);-webkit-background-clip:text;color:transparent}
.mi-feats{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
.mi-feat{display:flex;gap:8px;align-items:center;padding:9px 12px;border-radius:10px;background:#0a1530aa;border:1px solid #1e3a7a55;color:#22d3ee}
.mi-feat b{display:block;color:#fff;font-size:11px}.mi-feat small{color:#8ea2c8;font-size:9px}
.mi-mapwrap{position:relative;height:430px;border-radius:16px;overflow:hidden;border:1px solid #2a4fa088;box-shadow:0 0 40px #1d4ed844}
.mi-layers{position:absolute;z-index:500;top:12px;left:12px;width:170px;background:#050d22ec;border:1px solid #1e3a7a88;border-radius:12px;padding:8px;backdrop-filter:blur(8px)}
.mi-lh{font-size:9px;letter-spacing:.2em;color:#6f84ad;margin:2px 4px 6px}
.mi-lrow{display:flex;align-items:center;gap:7px;padding:6px;border-radius:7px;cursor:pointer;color:#b6c5e6}.mi-lrow span{flex:1}
.mi-lrow.act{background:#16306e88;box-shadow:inset 0 0 0 1px #3b82f6aa}.mi-lrow input{accent-color:#3b82f6}
.mi-storm{position:absolute;z-index:500;bottom:12px;left:12px;width:190px;background:#050d22ec;border:1px solid #7c3aed77;border-radius:12px;padding:10px}
.mi-sh{display:flex;align-items:center;gap:6px;margin-bottom:6px}.mi-sh em{margin-left:auto;font-style:normal;font-size:9px;background:#7c3aed55;color:#ddd6fe;padding:1px 6px;border-radius:5px}
.mi-kv{display:flex;justify-content:space-between;padding:2px 0;color:#8ea2c8}.mi-kv b{color:#fff}
.mi-btns{display:flex;gap:6px;margin-top:8px}.mi-btns button{flex:1;padding:5px;border-radius:6px;border:1px solid #2a4fa0;background:#0f1f4a;color:#cfe0ff;cursor:pointer}
.mi-legend{position:absolute;z-index:500;bottom:12px;right:12px;display:flex;gap:8px;align-items:center;background:#050d22ec;border-radius:8px;padding:6px 10px;color:#8ea2c8;font-size:10px}
.mi-legend i{width:110px;height:7px;border-radius:5px;background:linear-gradient(90deg,hsl(230 90% 55%),hsl(150 90% 55%),hsl(60 90% 55%),hsl(0 90% 55%))}
.mi-gauges{display:grid;grid-template-columns:repeat(6,1fr);gap:8px}
.mi-gauge{background:#0a1530aa;border:1px solid #1e3a7a55;border-radius:12px;padding:8px;display:flex;flex-direction:column;align-items:center}
.mi-gauge-t{font-size:9px;letter-spacing:.15em;color:#8ea2c8}.mi-gauge-s{font-size:9px;color:#6f84ad}
.mi-row3{display:grid;grid-template-columns:1fr 1.1fr 1.1fr;gap:12px}
.mi-panel{background:#08122acc;border:1px solid #1e3a7a66;border-radius:14px;padding:12px;backdrop-filter:blur(6px)}
.mi-panel-h{display:flex;align-items:center;gap:6px;font-weight:700;margin-bottom:10px;color:#fff}.mi-panel-h svg{color:#a78bfa}
.mi-chat ul{margin:6px 0;padding-left:16px;color:#b6c5e6;line-height:1.6}.mi-hi{margin:0;font-weight:600}.mi-hi small{color:#8ea2c8;font-weight:400}
.mi-chat .u{background:#1d4ed8;border-radius:8px;padding:6px 8px;margin:4px 0 4px 30px}.mi-chat .a{background:#13244a;border-radius:8px;padding:6px 8px;margin:4px 30px 4px 0;white-space:pre-wrap}
.mi-in{display:flex;gap:6px;margin-top:8px}.mi-in input{flex:1;background:#050d22;border:1px solid #1e3a7a;border-radius:8px;padding:7px 9px;color:#fff;outline:none}
.mi-in button{width:32px;border-radius:50%;border:0;background:#2563eb;color:#fff;cursor:pointer}
.mi-tc{display:flex;align-items:center;gap:8px}.mi-tc input{flex:1;accent-color:#3b82f6}
.mi-play{width:30px;height:30px;border-radius:8px;border:1px solid #3b82f6;background:#0f1f4a;color:#fff;cursor:pointer;display:grid;place-items:center}
.mi-badge{background:#2563eb;padding:2px 8px;border-radius:6px;font-weight:700}
.mi-tabs{display:inline-flex;margin:10px 0;background:#050d22;border-radius:8px;padding:2px}.mi-tabs button{background:none;border:0;color:#8ea2c8;padding:4px 12px;border-radius:6px;cursor:pointer}
.mi-tabs .act{background:#1d4ed8;color:#fff}
.mi-lg{font-size:10px;color:#8ea2c8;margin-bottom:4px}
.mi-bar{height:7px;border-radius:5px;background:linear-gradient(90deg,hsl(230 90% 55%),hsl(150 90% 55%),hsl(60 90% 55%),hsl(0 90% 55%))}
.mi-ticks{display:flex;justify-content:space-between;color:#6f84ad;font-size:9px;margin-top:3px}
.mi-cap{font-size:10px;color:#6f84ad;margin-top:4px}
.mi-stats{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;background:#08122acc;border:1px solid #1e3a7a66;border-radius:14px;padding:12px;box-shadow:0 0 30px #10b98122}
.mi-stats>div{display:flex;gap:10px;align-items:center;justify-content:center;color:#3b82f6}
.mi-stats b{display:block;font-size:17px;color:#fff}.mi-stats small{color:#8ea2c8}
.mi-right{min-width:0}.mi-fa{height:100%}
.mi-cur-h{font-size:9px;letter-spacing:.15em;color:#6f84ad;border-top:1px solid #1e3a7a55;padding-top:8px;margin:10px 0 6px}
.mi-cur{display:grid;grid-template-columns:auto 1fr;gap:8px;align-items:center}
.mi-big{font-size:34px;font-weight:700}.mi-big sup{font-size:14px;color:#8ea2c8}.mi-big small{display:block;font-size:10px;color:#8ea2c8;font-weight:400}
.mi-mini{grid-column:1/3;display:grid;grid-template-columns:1fr 1fr;gap:3px 10px;color:#8ea2c8}.mi-mini b{color:#fff;float:right}
.mi-hourly{display:flex;justify-content:space-between;text-align:center}.mi-hourly div{display:flex;flex-direction:column;gap:3px;align-items:center}.mi-hourly small{color:#8ea2c8}
.mi-day{display:grid;grid-template-columns:38px 22px 1fr 22px;gap:6px;align-items:center;padding:3px 0}.mi-day small{color:#8ea2c8}
.mi-rng{height:5px;background:#13244a;border-radius:4px;position:relative}.mi-rng i{position:absolute;top:0;bottom:0;border-radius:4px;background:linear-gradient(90deg,#22c55e,#facc15,#ef4444)}
.mi-aqi{display:flex;align-items:baseline;gap:8px;flex-wrap:wrap}.mi-aqi b{font-size:28px;text-shadow:0 0 12px currentColor}
.mi-al{display:flex;gap:8px;align-items:center;padding:7px;border:1px solid;border-radius:8px;margin-bottom:5px;background:#0a1530}
.mi-al i{width:6px;height:26px;border-radius:3px}.mi-al b{display:block;font-size:11px}.mi-al small{color:#8ea2c8}
@media(max-width:1200px){.mi-body{grid-template-columns:1fr}.mi-side{display:none}.mi-gauges{grid-template-columns:repeat(3,1fr)}.mi-row3{grid-template-columns:1fr}}
`;