import React, { useState } from 'react';
import { 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle, 
  Clock, 
  MapPin, 
  LifeBuoy, 
  Droplet, 
  Umbrella,
  BellRing
} from 'lucide-react';
import { api } from '../services/api';

export default function AlertsView({ alerts, onRefreshAlerts }) {
  const [resolvingId, setResolvingId] = useState(null);

  const handleResolve = async (id) => {
    setResolvingId(id);
    try {
      await api.resolveAlert(id);
      if (onRefreshAlerts) onRefreshAlerts();
    } catch (err) {
      console.error(err);
    } finally {
      setResolvingId(null);
    }
  };

  const getSeverityStyle = (severity) => {
    switch (severity) {
      case 'Emergency':
        return {
          badge: 'bg-rose-500/20 text-rose-400 border-rose-500/40',
          card: 'border-rose-500/40 bg-gradient-to-br from-rose-950/40 via-slate-900 to-slate-900',
          icon: <AlertTriangle className="w-5 h-5 text-rose-400 animate-bounce" />
        };
      case 'Warning':
        return {
          badge: 'bg-amber-500/20 text-amber-400 border-amber-500/40',
          card: 'border-amber-500/40 bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-900',
          icon: <ShieldAlert className="w-5 h-5 text-amber-400" />
        };
      default:
        return {
          badge: 'bg-blue-500/20 text-blue-400 border-blue-500/40',
          card: 'border-slate-800 bg-slate-900',
          icon: <BellRing className="w-5 h-5 text-blue-400" />
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Real-Time Heat Hazard & Extreme Microclimate Early Warning System
            </h2>
            <p className="text-xs text-slate-400">
              Automated municipal dispatch and citizen protection advisories triggered by IoT thermal thresholds
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-400 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
          <Clock className="w-4 h-4 text-emerald-400" />
          <span>Active Monitoring Cycle: Every 5s</span>
        </div>
      </div>

      {/* Active Alerts List */}
      <div className="space-y-4">
        {alerts.map((alert) => {
          const style = getSeverityStyle(alert.severity);
          return (
            <div 
              key={alert.id}
              className={`border rounded-2xl p-5 shadow-xl transition-all ${style.card} ${!alert.active ? 'opacity-60 grayscale' : ''}`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                    {style.icon}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="text-base font-bold text-white">{alert.title}</h4>
                      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${style.badge}`}>
                        {alert.severity}
                      </span>
                      {!alert.active && (
                        <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">
                          Resolved
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-slate-400 flex items-center space-x-2 mt-0.5">
                      <span className="flex items-center gap-1 font-mono text-slate-300">
                        <MapPin className="w-3.5 h-3.5 text-rose-400" /> {alert.zoneCode}
                      </span>
                      <span>•</span>
                      <span>Triggered: {new Date(alert.triggeredAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>
                </div>

                {alert.active && (
                  <button
                    onClick={() => handleResolve(alert.id)}
                    disabled={resolvingId === alert.id}
                    className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-emerald-300 text-xs px-3.5 py-1.5 rounded-xl border border-slate-700 transition cursor-pointer self-start sm:self-auto"
                  >
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                    <span>{resolvingId === alert.id ? 'Resolving...' : 'Acknowledge / Resolve'}</span>
                  </button>
                )}
              </div>

              {/* Description */}
              <p className="text-xs text-slate-300 mt-3">
                {alert.description}
              </p>

              {/* Advisories list */}
              {alert.advisories && alert.advisories.length > 0 && (
                <div className="mt-4 bg-slate-950/70 p-3.5 rounded-xl border border-slate-800/80 space-y-2">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Public Safety Directives & Municipal Action:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {alert.advisories.map((adv, idx) => (
                      <div key={idx} className="flex items-start space-x-2 text-slate-200">
                        <span className="text-rose-400 font-bold shrink-0">•</span>
                        <span>{adv}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Citizen Heat Resilience Guidance */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 text-xs space-y-2">
          <div className="flex items-center space-x-2 text-blue-400 font-bold">
            <Droplet className="w-4 h-4" />
            <span>Hydration & Cooling Havens</span>
          </div>
          <p className="text-slate-400 text-[11px]">
            Municipal misting corridors and potable cold water kiosks are activated in Zones CBD-CORE and OLD-TOWN.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 text-xs space-y-2">
          <div className="flex items-center space-x-2 text-amber-400 font-bold">
            <Umbrella className="w-4 h-4" />
            <span>Shaded Pedestrian Corridors</span>
          </div>
          <p className="text-slate-400 text-[11px]">
            High-albedo solar canopies erected along transit walkways; citizens advised to utilize North Avenue tree pathways.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 text-xs space-y-2">
          <div className="flex items-center space-x-2 text-rose-400 font-bold">
            <LifeBuoy className="w-4 h-4" />
            <span>Vulnerable Group Protection</span>
          </div>
          <p className="text-slate-400 text-[11px]">
            Community health volunteers dispatched to Old Town (23.4% senior population) with emergency electrolyte reserves.
          </p>
        </div>
      </div>
    </div>
  );
}
