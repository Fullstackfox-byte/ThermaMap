const API_BASE = '/api';

// ---- auth token helpers (used by Batch 2 login UI) ----
const TOKEN_KEY = 'auraUhiToken';
export const auth = {
  getToken: () => localStorage.getItem(TOKEN_KEY),
  setToken: (t) => localStorage.setItem(TOKEN_KEY, t),
  clear: () => localStorage.removeItem(TOKEN_KEY)
};

function authHeaders(extra = {}) {
  const token = auth.getToken();
  return token ? { ...extra, Authorization: `Bearer ${token}` } : extra;
}

export const api = {
  // Zones
  getZones: async () => {
    const res = await fetch(`${API_BASE}/zones`);
    return res.json();
  },
  getZone: async (code) => {
    const res = await fetch(`${API_BASE}/zones/${code}`);
    return res.json();
  },

  // Sensors
  getSensors: async () => {
    const res = await fetch(`${API_BASE}/sensors`);
    return res.json();
  },

  // Simulation
  evaluateMitigation: async (payload) => {
    const res = await fetch(`${API_BASE}/simulation/evaluate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    return res.json();
  },
  saveSimulation: async (payload) => {
    const res = await fetch(`${API_BASE}/simulation/save`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    return res.json();
  },

  // Mitigation Projects
  getProjects: async () => {
    const res = await fetch(`${API_BASE}/mitigation/projects`);
    return res.json();
  },
  createProject: async (project) => {
    const res = await fetch(`${API_BASE}/mitigation/projects`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(project)
    });
    return res.json();
  },
  voteProject: async (id) => {
    const res = await fetch(`${API_BASE}/mitigation/projects/${id}/vote`, {
      method: 'POST'
    });
    return res.json();
  },
  updateProjectStatus: async (id, status) => {
    const res = await fetch(`${API_BASE}/mitigation/projects/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    return res.json();
  },

  // Alerts
  getAlerts: async (activeOnly = false) => {
    const res = await fetch(`${API_BASE}/alerts${activeOnly ? '?active=true' : ''}`);
    return res.json();
  },
  resolveAlert: async (id) => {
    const res = await fetch(`${API_BASE}/alerts/${id}/resolve`, {
      method: 'PATCH'
    });
    return res.json();
  },

  // Analytics
  getDiurnalData: async () => {
    const res = await fetch(`${API_BASE}/analytics/diurnal`);
    return res.json();
  },
  getCorrelations: async () => {
    const res = await fetch(`${API_BASE}/analytics/correlations`);
    return res.json();
  },
  getRankings: async () => {
    const res = await fetch(`${API_BASE}/analytics/rankings`);
    return res.json();
  },
  getSummary: async () => {
    const res = await fetch(`${API_BASE}/analytics/summary`);
    return res.json();
  },

  // AI / ML
  getAiModel: async () => {
    const res = await fetch(`${API_BASE}/ai/model`);
    return res.json();
  },
  getHotspots: async () => {
    const res = await fetch(`${API_BASE}/ai/hotspots`);
    return res.json();
  },
  getRecommendations: async (zoneCode) => {
    const q = zoneCode ? `?zone=${encodeURIComponent(zoneCode)}` : '';
    const res = await fetch(`${API_BASE}/ai/recommendations${q}`);
    return res.json();
  },
  predictLst: async (payload) => {
    const res = await fetch(`${API_BASE}/ai/predict-lst`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    return res.json();
  },

  // Auth
  register: async (payload) => {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    return res.json();
  },
  login: async (payload) => {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    return res.json();
  },
  me: async () => {
    const res = await fetch(`${API_BASE}/auth/me`, { headers: authHeaders() });
    return res.json();
  }
};